import React, { useState } from 'react';
import Adminheader from './Adminheader';
import axios from 'axios';

function EditLeave(){


 
  const[user,setUser]=useState([]);
 
  const[status,setStatus]=useState();
  const[error,setError1]=useState("");
  
  function editLeave(){
    
    axios.put("http://localhost:8080/updateLeave/"+localStorage.getItem("userid")+"/"+localStorage.getItem("ldescription")+"/"+localStorage.getItem("fdate")+"/"+localStorage.getItem("tdate"),{
       
       
        leave_status: status

      })
    .then((response) => {
        setUser(response.data)
        alert('Updated leave successfully');
    })
    .catch((error) => {
    
      console.log(error)
    })
  }


    return(
        <div>
            <Adminheader/>
            <div class="container"><br/>
          <h2>Edit Leave</h2><br/>
          <div className = "card col-md-6 offset-md-3"><br/>
            <div class="container">
                <form action="adminHome" method="post">
                  <div class="col-sm-12">
                    <div class="form-group">
                      <label>Leave Status</label>
                      <select class="form-select" onInput={(event)=> setStatus(event.target.value)} aria-label="Default select example">
                        <option selected>Select Status</option>
                        <option>Approved</option>
                        <option>Rejected</option>
                      </select>
                    </div><br/>
                    <input type="button" class="btn btn-primary"  value="Submit" onClick={()=>editLeave()} /> 	
                    	<br/>
                  </div>
                </form> 
           </div>
        </div>
        </div>
        </div>
    )
}

export default EditLeave;