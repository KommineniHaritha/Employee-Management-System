import React from 'react';
import './Adminheader.css';
import logo from '../assets/emp.png';

function Adminheader(){

   function deleteStorage()
   {
   localStorage.removeItem("userId");
   }

    return(
        <div>
       
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="home">
            <img src={logo} onClick={()=>deleteStorage()} style={{height:"70px",width:"90px"}} alt=""/>
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
             </button>
             <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
               <ul class="navbar-nav">
               <li class="nav-item">
                     <a href="adminHome">Admin Home</a>
                  </li>
                
                  <li class="nav-item">
                     <a  href="viewAllEmployees">View Employees</a>
                  </li>
                  <li class="nav-item">
                     <a  href="leaveReport">Leave Report</a>
                  </li>
                  <li class="nav-item">
                      <a href="salaryReport"> Salary Report</a>
                  </li>
                  <li class="nav-item">
                     <a href="timeReport">Timesheet Report</a>
                  </li>
                  <li class="nav-item">
                     <a onClick={()=>deleteStorage()} href="home">Logout</a>
                  </li>
                
                </ul>
              </div>
          </div>
    </nav> 
   </div>
        
    )
}

export default Adminheader;