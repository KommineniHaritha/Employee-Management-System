import React,{useEffect, useState } from 'react'
import axios from 'axios';
import Adminheader from './Adminheader';
import './table.css';
import { useHistory } from 'react-router-dom';

function TimesheetReport()
{
   
    const[error,setError]=useState("");
    const[users,setUsers]=useState([]);
    let history = useHistory();
    
    useEffect(()=>{
        axios.get("http://localhost:8080/listTimesheets")
        .then((response) => {
            setUsers(response.data)
            
        })
        .catch((error) => {
          setError(error.response.data)
          console.log(error.response.data)
        })
    },[])

    /*function editTimesheet(id,work_description,hours,tdate)
    {
        localStorage.setItem("tid",id);
        localStorage.setItem("wdescription",work_description);
        localStorage.setItem("hour",hours);
        localStorage.setItem("tidate",tdate);
        history.push("/edittimesheet")
    }*/

    function approveTimesheet(id,work_description,hours,tdate)
    {
        axios.put("http://localhost:8080/updateTimesheet/"+id+"/"+work_description+"/"+hours+"/"+tdate,{
        
         timesheet_status: "Approved"
      })
        .then((response) => {
     
        alert('Timesheet Approved successfully');
        window.location.reload();
        
        })
        .catch((error) => {
    
      console.log(error)
        })
    }

    function rejectTimesheet(id,work_description,hours,tdate)
    {
        axios.put("http://localhost:8080/updateTimesheet/"+id+"/"+work_description+"/"+hours+"/"+tdate,{
        
         timesheet_status: "Rejected"
      })
        .then((response) => {
        alert('Timesheet Rejected');
        window.location.reload();

        })
        .catch((error) => {
           console.log(error)
        })
    }


      return(
          <div>
              <Adminheader/>
                <br/>
                <h2>Timesheet Report</h2>
            <br/>
            
            <a href="addtime"><button class="btn btn-primary btn-lg">Add Timesheet</button></a><br/><br/>
            <div class="table-responsive">
              <table class="table table-bordered">
                 
                      <tr><th>Id</th><th>Work Description</th><th> Working Hours</th><th>Date</th><th>Status</th><th>Approve/Reject</th></tr>
                      
                      <tbody>
                          {users.map((user)=><tr><td>{user.id}</td><td>{user.work_description}</td><td>{user.hours}</td><td>{user.tdate}</td><td>{user.timesheet_status}</td>
                          { user.timesheet_status==="Rejected"?<div style={{textAlign:"center"}}>Already Rejected</div>: user.timesheet_status==="Approved"?<div  style={{textAlign:"center"}}>Already Approved</div>:
                          <td> <button class="btn btn-warning" onClick={()=>approveTimesheet(user.id,user.work_description,user.hours,user.tdate)}>Approve</button> 
                          <button style={{marginLeft: "10px"}} class="btn btn-danger" onClick={()=>rejectTimesheet(user.id,user.work_description,user.hours,user.tdate)}>Reject</button></td> }</tr>)}
                      </tbody>
              </table><br/>
          </div>
          </div>
      )
}

export default TimesheetReport;