import React, { useState } from 'react';
import Adminheader from './Adminheader';
import axios from 'axios';
import {useForm} from "react-hook-form";
import $ from 'jquery';
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

function AddTimesheet(){

 var required=true;

  const [errorList, setErrorList] = useState([]);

  const[userId,setUserId]=useState();
  const[user,setUser]=useState([]);
  const[description,setDescription]=useState();
  const[date,setDate]=useState();
  const[status,setStatus]=useState();
  const[hours,setHours]=useState();
  const[error1,setError1]=useState("");


  function addNewTimesheet(){

    if(userId== null || description== null|| hours== null|| date==="" || status== null){
      setErrorList(["*All input fields are required. Please enter all fields*"]);
      console.log(errorList);
    }else{
      if(!(userId== null || description== null|| hours== null|| date==="" || status== null)){
        setErrorList([null]);
        console.log(errorList);

    axios.post("http://localhost:8080/addTimesheet/",{
        id: userId,
        work_description: description,
        hours:hours,
        tdate: date,
        timesheet_status: status
      })
    .then((response) => {
        setUser(response.data)
        alert('Added successfully');
    })
    .catch((error1) => {
      setError1(error1.response.data)
      console.log(error1.response.data)
    })
  }
  }
  }

  $(function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;

    // or instead:
    // var maxDate = dtToday.toISOString().substr(0, 10);

    
    $('#todayDate').attr('max', maxDate);
    
});


    return(
        <div>
            <Adminheader/>
            <div class="container"><br/>
            <h2>Add Timesheet</h2><br/>
            <div className = "card col-md-6 offset-md-3"><br/>
            <div class="container">
            <form class="row g-3 needs-validation" >
           
          {errorList.map((msg) => (
            <li style={{ color: "red" }}>{msg}</li>
          ))}
  
                    <div class="col-sm-12">
                      <div class="form-group">
                        <label>Employee Id</label>
                        <input type="int" placeholder="Enter Employee id.." class="form-control" pattern="[0-9]{1}[0-9]{2}" onInput={(event)=> setUserId(event.target.value)} required={required}/>
                        
                      </div>	<br/>
                      <div class="form-group">
                        <label>Work Description</label>
                        <textarea placeholder="Enter Work Description Here.." rows="2" class="form-control" onInput={(event)=> setDescription(event.target.value)} required={required}></textarea>
                      
                    </div><br/>
                    <div class="form-group">
                        <label>Working hours</label>
                        <input type="number" min="2" max="10" placeholder="Total working hours." class="form-control" onInput={(event)=> setHours(event.target.value)} required={required}/>
                    </div><br/>
                    <div class="form-group">
                      <label>Date</label>
                        <input type="date" placeholder="Select Date" class="form-control" id="todayDate" min="2021-06-02" 
                          onInput={(event)=> setDate(event.target.value)}  required={required}/>
                    </div><br/>
                    <div class="form-group">
                      <label>Status</label>
                      <select class="form-select" onInput={(event)=> setStatus(event.target.value)} required={required}>
                        <option selected>Select Status</option>
                        <option>Approved</option>
                        <option>Rejected</option>
                      </select>
                    </div>
                    </div>
                    <input type="button" class="btn btn-primary" value="Submit" onClick={()=>addNewTimesheet()} /> 	
                    {error1}
                   
               
            </form>
        </div>
    </div>
</div>
        </div>
    )
}

export default AddTimesheet;