import React, { useState } from 'react';
import Adminheader from './Adminheader';
import axios from 'axios';

function AddLeave(){

  const[userId,setUserId]=useState();
  const[leave,setLeave]=useState();
  const[user,setUser]=useState([]);
  const[fdate,setFdate]=useState();
  const[tdate,setTdate]=useState();
  const[status,setStatus]=useState();
  const[error,setError]=useState("");;

  const [errorList, setErrorList] = useState([]);

  function addNewLeave(){
    if(userId== null || leave== null|| fdate===""|| tdate==="" || status== null)
    {
      setErrorList(["*All input fields are required. Please enter all fields*"]);
      console.log(errorList);
    }
    else
    {
      if(!(userId== null || leave== null|| fdate===""|| tdate==="" || status== null))
      {
        setErrorList([null]);
        console.log(errorList);
    
        axios.post("http://localhost:8080/addLeave/",{
        id: userId,
        leave_description: leave,
        from_date:fdate,
        to_date: tdate,
        leave_status: status

      })
    .then((response) => {
        setUser(response.data)
        alert('Added successfully');
    })
    .catch((error) => {
      setError(error.response.data)
      console.log(error.response.data)
    })
  }
  }
}


    return(
        <div>
            <Adminheader/>
            <div className="container"><br/>
          <h2>Add Leave</h2><br/>
          <div className = "card col-md-6 offset-md-3"><br/>
            <div className="container">
                <form class="row g-3 needs-validation" >
               
          {errorList.map((msg) => (
            <li style={{ color: "red" }}>{msg}</li>
          ))}
        
                  <div className="col-sm-12">
                    <div className="form-group">
                      <label>Employee Id</label>
                      <input type="int" name="id" placeholder="Enter Employee id.." className="form-control" pattern="[1-9]{1}[0-9]{2}" onInput={(event)=> setUserId(event.target.value)} required/>
                    </div>	<br/>
                 
                    <div className="form-group">
                      <label>Leave Description</label>
                      <textarea placeholder="Enter Leave Description Here.." name="leave_description" rows="2" className="form-control" onInput={(event)=> setLeave(event.target.value)}required></textarea>
                      
                    </div><br/>
                    <div className="form-group">
                      <label>From Date</label>
                      <input type="date" placeholder="Select From Date" className="form-control" onInput={(event)=> setFdate(event.target.value)} required />
                      
                    </div>	<br/>
                    <div className="form-group">
                      <label>To Date</label>
                      <input type="date" placeholder="Select To Date"  className="form-control" onInput={(event)=> setTdate(event.target.value)} required/>
                  
                    </div>	<br/>
                    <div className="form-group">
                      <label>Leave Status</label>
                      <select className="form-select" name="leave_status" onInput={(event)=> setStatus(event.target.value)} aria-label="Default select example">
                        <option selected>Select Status</option>
                        <option>Approved</option>
                        <option>Rejected</option>
                      </select>
                    </div>
                    </div>
                    <input type="button" className="btn btn-success"  value="Submit" onClick={()=>addNewLeave()} /> 	
                    	{error}
                  
                </form> 
           </div>
        </div>
        </div>
        </div>
    )
}

export default AddLeave;