import React,{ useEffect, useState } from 'react'
import axios from 'axios';
import Adminheader from './Adminheader';
import './table.css';

function SalaryReport()
{
   const[month,setMonth]=useState();
    const[error,setError]=useState("");
    const[users,setUsers]=useState([]);

    useEffect(()=>{
        axios.get("http://localhost:8080/listSalaries")
        .then((response) => {
            setUsers(response.data)
            
        })
        .catch((error) => {
          setError(error.response.data)
          console.log(error.response.data)
        })
      },[])

      function searchByMonth()
      {
        axios.get("http://localhost:8080/getByMonth/"+month)
        .then((response) => {
            setUsers(response.data)
            
        })
        .catch((error) => {
          setError(error.response.data)
          console.log(error.response.data)
        })
      }
      

      return(
        <div>
            <Adminheader/><br/>
            <h2>Salary Report</h2>
            <br/>
            <div class="container">

            <label>Search Salary By Month</label>
        <select  onChange={(event)=> setMonth(event.target.value)}>
            <option>Choose Month</option>
            <option>January</option>
            <option>February</option>
            <option>March</option>
            <option>April</option>
            <option>May</option>
            <option>June</option>
            <option>July</option>
            <option>August</option>
            <option>September</option>
            <option>October</option>
            <option>November</option>
            <option>December</option>
        </select>
        <input type="button" style={{marginLeft: "10px"}} class="btn btn-warning" value="Search" onClick={()=>searchByMonth()} /> <br/><br/>

            <a href="addsalary"><button class="btn btn-primary btn-lg">Add Salary</button></a><br/><br/>

              <table class="table table-bordered">
                 
                      <tr><th>Id</th><th>Month</th><th>Year</th><th>Amount</th></tr>
                      
                      <tbody>
                          {users.map((user)=><tr><td>{user.id}</td><td>{user.sal_month}</td><td>{user.sal_year}</td><td>{user.amount}</td></tr>)}
                      </tbody>
              </table><br/>
                   </div>
          </div>
      )
}

export default SalaryReport;