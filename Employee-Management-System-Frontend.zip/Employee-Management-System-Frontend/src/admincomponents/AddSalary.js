import React, { useState } from 'react';
import Adminheader from './Adminheader';
import axios from 'axios';

function AddSalary(){
  const [errorList, setErrorList] = useState([]);

  const[userId,setUserId]=useState();
  const[month,setMonth]=useState();
  const[user,setUser]=useState([]);
  const[year,setYear]=useState();
  const[amount,setAmount]=useState();
  const[error,setError]=useState("");

  function addNewSalary(){
    if(userId== null || month==="" || year== null|| amount==null){
      setErrorList(["*All input fields are required. Please enter all fields*"]);
      console.log(errorList);
    }
    else{
      if(!(userId== null || month==="" || year== null|| amount==null) ){
        setErrorList([null]);
        console.log(errorList);
    axios.post("http://localhost:8080/addSalary/",{
        id: userId,
        sal_month:month,
        sal_year:year,
        amount:amount
      })
    .then((response) => {
        setUser(response.data)
        alert('Added successfully');
    })
    .catch((error) => {
    alert("Employee id does not exist / Same data already exists");
      console.log(error.response.data)
    })
  }
  }
  }
    return(
        <div>
            <Adminheader/>
              <div class="container"><br/>
          <h2>Add Salary</h2><br/>
          <div className = "card col-md-6 offset-md-3"><br/>
            <div class="container">
              <form class="row g-3 needs-validation">
           
          {errorList.map((msg) => (
            <li style={{ color: "red" }}>{msg}</li>
          ))}
      
                  <div class="col-sm-12">
                    <div class="form-group">
                      <label>Employee Id</label>
                      <input type="int" placeholder="Enter Employee id.." class="form-control" onInput={(event)=> setUserId(event.target.value)} required/>      
                    </div>	<br/>    
                    <div class="form-group">
                      <label>Month</label>
                      <select class="form-select" onInput={(event)=> setMonth(event.target.value)} required >
                        <option selected>Select Month</option>
                        <option>January</option>
                        <option>February</option>
                        <option>March</option>
                        <option>April</option>
                        <option>May</option>
                        <option>June</option>
                        <option>July</option>
                        <option>August</option>
                        <option>September</option>
                        <option>October</option>
                        <option>November</option>
                        <option>December</option>
                      </select>
                    </div><br/>
                    <div class="form-group">
                      <label>Year</label>
                      <select class="form-select" aria-label="Default select example" onInput={(event)=> setYear(event.target.value)} required>
                        <option selected>Select Year</option>
                        <option>2021</option>
                      </select>
                    </div><br/>
                    <div class="form-group">
                      <label>Enter Amount</label>
                      <input type="int" placeholder="Enter Amount Here.." class="form-control" onInput={(event)=> setAmount(event.target.value)} required/>  
                  </div>	
                  </div>
                    <input type="button" class="btn btn-primary" value="Submit" onClick={()=>addNewSalary()} /> <br/>			
                </form>
              </div>
            </div>
        </div>  
        </div>
    )
}

export default AddSalary;