import React,{ useState } from 'react'
import axios from 'axios';
import Header from '../menucomponents/Header';
import './Adminlogin.css'
import { useHistory } from 'react-router-dom';

function Adminlogin(){
    const [login, setLogin] = useState({ });
    const [errorList, setErrorList] = useState([]);
    const[users,setUsers]=useState();
    let history = useHistory();
  
     const getvalues = (event) => {
      setLogin({ ...login, [event.target.name]: event.target.value });
      console.log(login);
    };
  
    function validate() {
      if (login.id =="" || login.password === "") {
        setErrorList(["Id is required", "Password is required"]);
        console.log(errorList);
      } else {
        axios
          .post("http://localhost:8080/adminlogin/", login)
          .then((response) => {
            history.push('/AdminHome')
          alert("Successfully loggedin")
              
          })
          .catch((error) => {
           setErrorList(["Invalid id/password"]);
          
          });
      }
    }
    return(
          
        <div>
        <Header/>
        <div class="container login-container">
            <div class="col-md-6 login-form-2">
          
              <h3>Admin login</h3><br/>
                     
          <ul>
          {errorList.map((msg) => (
            <li style={{ color: "white" }}>{msg}</li>
          ))}
        </ul>
      
        <input type="int" className="form-control" name="id" placeholder="enter id" onChange={getvalues} required ></input>
        <br/>
       
        <input type="password" className="form-control" name="password" placeholder="enter password" onChange={getvalues} required></input>
        <br></br>
  
        <div class="form-group">
            <input type="submit" class="btnSubmit" value="Login" onClick={()=>validate()} />
        </div><br/>
          
            </div>
        </div>
    </div>
      )
}
export default Adminlogin;