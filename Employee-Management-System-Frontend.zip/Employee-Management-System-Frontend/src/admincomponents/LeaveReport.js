import React,{useEffect, useState } from 'react'
import axios from 'axios';
import Adminheader from './Adminheader';
import './table.css';

function LeaveReport()
{
    const[error,setError]=useState("");
    const[users,setUsers]=useState([]);
      
    useEffect(()=>{
        axios.get("http://localhost:8080/listLeaves")
        .then((response) => {
            setUsers(response.data)
            
        })
        .catch((error) => {
          setError(error.response.data)
          console.log(error.response.data)
        })
    },[])

 /*  function editLeave(id,leave_description,from_date,to_date)
    {
      localStorage.setItem("userid",id)
      localStorage.setItem("fdate",from_date)
      localStorage.setItem("tdate",to_date)
      localStorage.setItem("ldescription",leave_description)
         history.push("/editleave")
    }
*/
    function approveLeave(id,leave_description,from_date,to_date)
    {
    
      axios.put("http://localhost:8080/updateLeave/"+id+"/"+leave_description+"/"+from_date+"/"+to_date,{
        leave_status: "Approved"
            
      })
    .then((response) => {
      
        alert('Approved leave successfully');
        window.location.reload();
      
    })
    .catch((error) => {
    
      console.log(error)
    })
    }

    function rejectLeave(id,leave_description,from_date,to_date)
    {
      axios.put("http://localhost:8080/updateLeave/"+id+"/"+leave_description+"/"+from_date+"/"+to_date,{
        leave_status: "Rejected"
        
      })
    .then((response) => {
    
       alert('Leave Rejected');
        window.location.reload();
    })
    .catch((error) => {
    
      console.log(error)
    })
    }

 
      return(
          <div>
              <Adminheader/>
                <br/>
                <h2>Leave Report</h2>
            <br/>
            <a href="addleave"><button class="btn btn-primary btn-lg">Add Leave</button></a><br/><br/>

            <div class="table-responsive">
              <table class="table table-bordered">
                 
                      <tr><th>Id</th><th>Description</th><th>From_Date</th><th>To_Date</th><th>Status</th><th>Approve/Reject</th></tr>
                      
                      <tbody>
                          {users.map((user)=>
                          <tr><td>{user.id}</td>
                          <td>{user.leave_description}</td>
                          <td>{user.from_date}</td>
                          <td>{user.to_date}</td>
                          <td>{user.leave_status}</td>
                          { user.leave_status==="Rejected"?<div style={{textAlign:"center"}}>Already Rejected</div>: user.leave_status==="Approved"?<div  style={{textAlign:"center"}}>Already Approved</div>:
                          <td> <button class="btn btn-warning" 
                           onClick={()=>approveLeave(user.id,user.leave_description,user.from_date,user.to_date)}>Approve</button> 
                           <button style={{marginLeft: "10px"}} class="btn btn-danger" 
                           onClick={()=>rejectLeave(user.id,user.leave_description,user.from_date,user.to_date)}>Reject</button> </td>} </tr>)}
                      </tbody>
              </table><br/>
          </div>
          </div>
      )
}

export default LeaveReport;