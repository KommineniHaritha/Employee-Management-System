import React from 'react';
import Footer from '../menucomponents/Footer';
import logo from '../assets/home1.jpg';
import slide1 from '../assets/salary.jpg';
import slide2 from '../assets/salary1.jpg';

function Managesalary()
{
    return(
        <div>
              <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="adminHome">
                         <img src={logo}  style={{height:"70px",width:"90px"}} alt=""/>
                     </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                         <span class="navbar-toggler-icon"></span>
                    </button> 
                     <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                 <a href="addsalary">Add Salary</a>
                            </li>
                            <li class="nav-item">
                                <a href="salaryReport">Salary Report</a>
                            </li>
                
                        </ul>
                    </div>
                </div>
            </nav>
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src={slide1} class="d-block w-100" alt="EmpHome" style={{height:"450px",width:"500px"}}/>
              </div>
              <div class="carousel-item">
                <img src={slide2} class="d-block w-100" alt="EmpHome" style={{height:"450px",width:"500px"}} />
              </div>
            </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
        </div><br/><br/>
        <div class="container"> 
        <h2 >Challenges in payroll processing</h2>

          <p>Salary processing is a critical yet important task for the human resource team irrespective of the industry type. Any error in payroll calculation and other related duties like wrong salary calculations, incorrect tax deductions, error in attendance records, can cost an organization dearly in the form of penalties. Also, it makes your employees unhappy!</p>

            <p>Below is the list of some major challenges in payroll that Human resource professionals experience during salary processing;</p>

        <ul>
	        <li >Stages in Salary Processing</li>
	        <li >Correct employee classification</li>
	        <li >Time tracking and attendance</li>
        	<li >Benefits and deductions</li>
	        <li >Tax deductions</li>
	        <li >Salary credit</li>
        </ul>

        <h2 >Stages in Salary Processing</h2>

            <p>Payroll and other related activities are repetitive, tedious and important and hence, opting for payroll system is a big relief for pvt ltd and public sector companies. The software of payroll includes various built-in tools to support different stages of payroll that makes the whole process hassle free and quicker.</p>

          <h3 >Correct employee classification</h3>

            <p>By the proper classification of employee&#39;s, companies are able to determine who are eligible for tax exemptions and who are not. Also, it helps you to issue them certain forms and you can be aware of which taxes need to be withheld.</p>

        <h3 >Time tracking and attendance</h3>

    <p>Before calculating the final amount, you need to consider some important parameters such as loss of pay (LOP), approved leaves, unapproved leaves, reimbursements and compensatory amount (if any).</p>

      <h3>Benefits and deductions</h3>

        <p>Some common type of deductions are provident fund (PF), employees state insurance (ESIC) and professional tax (PTAX). ESIC deductions vary from state to state and it covers health insurance of employees. Professional tax is the direct tax collected by the Indian government.</p>

              <h3 >Tax deductions</h3>

      <p>Calculating precise tax deductions is necessary for future audits. This is very much important for employers to calculate the correct amount of taxes and pay employees the exact amount to avoid any type of penalties and legal actions.</p>

    <h3 >Salary credit</h3>

    <p>This is the pay day on which the payroll team issues the payments to your employees.</p>

      <h2 >Features of payroll software</h2>

    <ul>
	    <li >Cost-efficient</li>
	    <li >Intuitive time and attendance management</li>
	    <li >Full email integration</li>
	    <li >Swift implementation</li>
	    <li >Real-time insights</li>
	    <li >Multi-location support</li>
      <li >Worry-free storage</li>
	    <li >Liberty to customize</li>
	    <li>Paperless payroll</li>
  </ul>
  </div><br/>
  <Footer/>
      </div>
    )
}

export default Managesalary;