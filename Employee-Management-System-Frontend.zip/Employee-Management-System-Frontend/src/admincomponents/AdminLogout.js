import React,{ useState } from 'react'
import axios from 'axios';
import Adminheader from './Adminheader';
import { useHistory } from 'react-router-dom';

function AdminLogout()
{
    let history = useHistory();

    function deleteStorage()
    {
    localStorage.removeItem("userId");
    history.push("/home")
    }
   
    return(

      <div>
        <Adminheader/><br/>
        <div class="container">
        <h3>Logout</h3><br/>
   
        <button class="btn btn-primary btn-lg" onClick={deleteStorage}>Logout</button>
        </div>
        </div>
        
    )
}

export default AdminLogout;