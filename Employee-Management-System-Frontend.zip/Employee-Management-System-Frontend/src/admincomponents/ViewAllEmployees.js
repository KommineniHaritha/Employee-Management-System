import React,{ useEffect, useState } from 'react'
import axios from 'axios';
import Adminheader from './Adminheader';
import { useHistory } from 'react-router-dom';
import './table.css';


function ViewAllEmployees()
{
    const[error,setError]=useState("");
    const[users,setUsers]=useState([]);
    let history = useHistory();
    const [isSubmitted, setIsSubmitted] = useState(false);

    function submitForm() {
      setIsSubmitted(true);
    }

      useEffect(()=>{
        axios.get("http://localhost:8080/listEmployees")
        .then((response) => {
            setUsers(response.data)
            
        })
        .catch((error) => {
        
          console.log(error)
        })
      },[])

      function deleteEmployee(id)
      {
          axios.get("http://localhost:8080/deleteEmployee/"+id)
         .then((response) => {
        
                  alert('Successfully deleted')
                  window.location.reload();
          })
          .catch((error) => {
         
              console.log(error)
          })
      }

     function editUser(id)
      {
        localStorage.setItem("userId",id)
           history.push("/editemp")
      }

      return(
        <div>
            <Adminheader/><br/>
            <h2>View all Employees</h2>
            
            <a href="addemp"><button class="btn btn-primary btn-lg" submitForm={submitForm} >Add Employee</button></a><br/><br/>

            <div class="table-responsive">

              <table class="table table-bordered">
                 
                      <tr><th>Id</th><th>Fname</th><th>Lname</th><th>Email Id</th><th>State</th>
                      <th>Designation</th><th>Phone</th><th>Edit</th><th>Delete</th></tr>
                      
                      <tbody>
                          {users.map((user)=><tr><td>{user.id}</td><td>{user.fname}</td><td>{user.lname}</td><td>{user.email}</td>
                          <td>{user.state}</td><td>{user.designation}</td><td>{user.phone}</td>
                          <td> <button class="btn btn-warning" onClick={()=>editUser(user.id)}>Edit</button> </td>
                          <td> <button class="btn btn-danger" onClick={()=>deleteEmployee(user.id)}>Delete</button> </td></tr>)}
                      </tbody>
              </table>
            </div>
          </div>
      )
}

export default ViewAllEmployees;