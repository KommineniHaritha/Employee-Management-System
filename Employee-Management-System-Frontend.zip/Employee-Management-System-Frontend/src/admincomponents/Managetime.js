import React from 'react';
import Footer from '../menucomponents/Footer';
import logo from '../assets/home1.jpg';
import slide1 from '../assets/managetimesheet1.jpg';
import slide2 from '../assets/timesheet.png';
import img1 from '../assets/timesheet1.webp';
import img2 from '../assets/Flexible-timesheet-management-system.webp';
import img3 from '../assets/Go-modern-with-Digital-timesheets.jpg';
import img4 from '../assets/managetime.webp';

function Managetime()
{
    return(
        <div>
              <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="adminHome">
                         <img src={logo}  style={{height:"70px",width:"90px"}} alt=""/>
                     </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                         <span class="navbar-toggler-icon"></span>
                    </button> 
                     <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                 <a href="addtime">Add Timesheet</a>
                            </li>
                            <li class="nav-item">
                                <a href="timeReport">Timesheet Report</a>
                            </li>
                
                        </ul>
                    </div>
                </div>
            </nav>
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src={slide1} class="d-block w-100" alt="EmpHome" style={{height:"450px",width:"500px"}}/>
              </div>
              <div class="carousel-item">
                <img src={slide2} class="d-block w-100" alt="EmpHome" style={{height:"450px",width:"500px"}}/>
              </div>
            </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
        </div><br/>
        <section class="one-platform go-paperless">
            <div class="container">
                  <div class="headings text-center">
                    <h2 ><span>Timesheet management no more a hurdle!</span></h2>
                  </div><br/>
                <div class="row justify-content-between">
                  <div class="card text-white bg-secondary mb-3" style={{maxWidth: "18em"}}>
                    <div class="card-body">
                      <h5 class="card-title">Tailored time-sheets</h5>
                      <p class="card-text">Customize and set-up workflow with respect to your requirements. </p>
                    </div>
                  </div>
                  <div class="card text-dark bg-warning mb-3" style={{maxWidth: "18em"}}>
                    <div class="card-body">
                        <h5 class="card-title">Remote working</h5>
                        <p class="card-text">Automated employee tracking lets you perform through remote locations as well.</p>
                    </div>
                  </div>
                  <div class="card text-white bg-danger mb-3" style={{maxWidth: "18em"}}>
                    <div class="card-body">
                      <h5 class="card-title">Technology-oriented time-sheeting</h5>
                      <p class="card-text">Go digital with our modern age automated timesheet management system.</p>
                    </div>
                  </div>
                </div>
              </div>
          </section><br/><br/>
          <section class="best-payroll-software">
            <div class="container">
              <div class="row align-items-center justify-content-between">
                <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center">
                  <img src={img1} alt="timesheet management" class="w-100"/>
                </div>
                <div class="col-lg-6">
                  <div class="headings mb-4">
                      <h3><span class="d-block">Timesheets tailored as per your business needs</span></h3>
                  </div>
                  <p>Our timesheet management software is easy to set up and use. Our employee timesheet software enables HR department to easily manage, track and record timesheets. It also allows you to customize the process workflow as per your business requirements.</p>
                </div>
              </div>
              </div>
          </section><br/>
          <div class="feature-details">
            <div class="container">
              <div class="row align-items-center py-5 feature-service-details">
                <div class="col-lg-6 order-2 order-lg-1">
                  <div class="headings mb-3">
                    <h3><span>Flexible timesheet management software</span></h3>
                  </div>
                  <p>Now timesheet management is not that hectic as it used to be earlier. Our timesheet software allows you to access and submit timesheets from anywhere anytime. It even provides the flexibility to work from any location.</p>
                </div>
                <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center order-1 order-lg-2">
                  <img src={img2} alt="Online timesheet management software" class="w-100"/>
                </div>
              </div>
              <div class="row align-items-center py-5 feature-service-details">
                <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center">
                  <img src={img3} alt="Digital Timesheets" class="w-100"/>
                </div>
                <div class="col-lg-6">
                  <div class="headings mb-3">
                    <h3><span>Go modern with Digital timesheets</span></h3>
                  </div>
    
                  <p>Employees often prefer up-to-date workplaces. An up-to-date workplace consists of modern i.e. digitally performing systems and technology driven management. Employee self-service portal available on mobile can make it easy for them to punch-in and out through app. Remote workers can now update their timesheets from anywhere without a second thought.</p>
                </div>
              </div>
              <div class="row align-items-center py-5 feature-service-details">
                <div class="col-lg-6 order-2 order-lg-1">
                  <h2>Online Timesheet Management</h2>
    
                     <p>An automated, online timesheet software makes your timesheet management much more sorted and foolproof. It prevents loopholes like buddy punching and miscalculations in attendance. Therefore, it also contributes towards unerring attendance tracking of workforce. The online availability of timesheet updation promotes remote working along with improved productivity and accuracy.</p>
                </div>
                <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center order-1 order-lg-2">
                  <img src={img4} alt="" class="w-100"/>
                </div>
              </div>
              <h3 >What are the Benefits of using Timesheet Management?</h3>

              <ul >
	                <li >Remote workforce management</li>
                	<li >Reduce time wastage</li>
                	<li >Easy reporting</li>
	                <li >Human errors at bay</li>
	                <li >Employee productivity</li>
                	<li >Improves communication</li>
                	<li >Easy data access</li>
              </ul>
            </div>
          </div><br/>
          <Footer/>
        </div>
    )
}

export default Managetime;