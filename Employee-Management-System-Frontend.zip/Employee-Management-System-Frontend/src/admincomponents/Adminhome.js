import React from 'react';
import Adminheader from './Adminheader';
import img1 from '../assets/manageemp.jfif';
import img2 from '../assets/mngleave.jpg';
import img3 from '../assets/managesal.jfif';
import img4 from '../assets/managetime.webp';
import Footer from '../menucomponents/Footer';
function Adminhome(){
    return(
        <div>
            <Adminheader/>

        <div class="container"><br/>
          <h2>Welcome Admin</h2><br/>
          <div class="row row-cols-1 row-cols-md-2 g-4">
            <div class="col">
              <div class="card">
                <img src={img1} class="card-img-top" alt="Manage Employees"/>
                <div class="card-body">
                  <h5 class="card-title">Employee Management</h5>
                  <p class="card-text">An employee management system is a platform where all work-related as well as important personal details of an employee is stored and managed in a secure way. By using this system, you can manage admin activities in an easier and quicker way.</p>
                  <a href="manageemp" class="btn btn-primary">Manage Employees</a>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card">
                <img src={img2} class="card-img-top" alt="Manage Leaves" style={{height:"370px",width:"300"}}/>
                <div class="card-body">
                  <h5 class="card-title">Leave Management</h5>
                  <p class="card-text">You can manage and track employee leaves with our dedicated leave management system. It allows an employer to accurately allocate, track, manage and grant/reject leave and also employees can request and track their own leaves.</p>
                  <a href="manageleave" class="btn btn-primary">Manage Leaves</a>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card">
                <img src={img3} class="card-img-top" alt="Manage Salary" style={{height:"300px",width:"300"}}/>
                <div class="card-body">
                  <h5 class="card-title">Salary Management</h5>
                  <p class="card-text">Payroll Software is used to manage and streamline the process of making salaries to employees.</p>
                  <a href="managesalary" class="btn btn-primary">Manage Salary</a>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card">
                <img src={img4} class="card-img-top" alt="Manage Timesheet" style={{height:"300px"}}/>
                <div class="card-body">
                  <h5 class="card-title">Timesheet Management</h5>
                  <p class="card-text">Our timesheet software allows you to access and submit timesheets from anywhere anytime. It even provides the flexibility to work from any location.</p>
                  <a href="managetimesheet" class="btn btn-primary">Manage Timesheet</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <br/><br/>
        <Footer/>
        </div>

    )
}
export default Adminhome;
