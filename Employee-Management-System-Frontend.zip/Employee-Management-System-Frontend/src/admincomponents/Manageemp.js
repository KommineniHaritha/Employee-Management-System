import React from 'react';

import logo from '../assets/home1.jpg';
import slide1 from '../assets/Employee management.jpg';
import slide2 from '../assets/manageemp2.jpg';
import home1 from '../assets/Employee management system.jpg';
import home2 from '../assets/Online-employee-management.webp';
import Footer from '../menucomponents/Footer';
function Manageemp(){
    return(
        <div>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="adminHome">
            <img src={logo}  style={{height:"70px",width:"90px"}} alt=""/>
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
             </button> 
             <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
               <ul class="navbar-nav">
                  <li class="nav-item">
                     <a href="addemp">Add Employee</a>
                  </li>
                  <li class="nav-item">
                     <a href="viewAllEmployees"> View Employees</a>
                  </li>
                
                </ul>
              </div>
          </div>
    </nav> 
        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src={slide1} class="d-block w-100" alt="EmpHome" style={{height:"450px",width:"500px"}}/>
              </div>
              <div class="carousel-item">
                <img src={slide2} class="d-block w-100" alt="EmpHome" style={{height:"450px",width:"500px"}}/>
              </div>
            </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
        </div><br/>
        <section class="one-platform go-paperless">
            <div class="container">
                  <div class="headings text-center">
                    <h2 ><span>Employee Management System </span></h2>
                  </div><br/>
                <div class="row justify-content-between">
                  <div class="card text-white bg-primary mb-3" style={{maxWidth: "18em"}}>
                    <div class="card-body">
                      <h5 class="card-title">Rescue more time</h5>
                      <p class="card-text">Save substantial amount of time with our employee management system. </p>
                    </div>
                  </div>
                  <div class="card text-dark bg-warning mb-3" style={{maxWidth: "18em"}}>
                    <div class="card-body">
                        <h5 class="card-title">Better decisions</h5>
                        <p class="card-text">The analytically driven metric system provides best insights of business.</p>
                    </div>
                  </div>
                  <div class="card text-white bg-danger mb-3" style={{maxWidth: "18em"}}>
                    <div class="card-body">
                      <h5 class="card-title">Employee self-service</h5>
                      <p class="card-text">Let your employees service themselves to save more time at HR base.</p>
                    </div>
                  </div>
                </div>
              </div>
          </section><br/><br/>
          <section class="best-payroll-software">
            <div class="container">
              <div class="row align-items-center justify-content-between">
                <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center">
                  <img src={home1} alt="employee management system" class="w-100"/>
                </div>
                <div class="col-lg-6">
                  <div>
                    <h2><span>What is Employee Management System?</span></h2>
                  </div>
                  <p>An Employee Management System is a platform where all work-related as well as important personal details of an employee is stored and managed in a secure way. By using this system, you can manage admin activities in an easier and quicker way.</p>
                  <p>Employees are the pillar of any organization and an ideal employee management tool makes a big difference to an organization.</p>
                </div>
              </div>
            </div>
        </section>
            <div class="container">
                <div class="row align-items-center py-5 feature-service-details">
                    <div class="col-lg-6 order-2 order-lg-1">
                      <div class="headings mb-3">
                        <h3><span>Online Employee Management</span></h3>
                      </div>
                      <p>Tracing and recording of the employee data had never been easier. Creating a proper employee database is an important to-do task for perfect payroll. Our online employee management software is an essential tool to count exact worked hours and creates the required database for every month. Also, automation helps in cutting down errors. The <strong>online employee management system</strong> lets your HR work from any remote location as well.</p>
                    </div>
                    <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center order-1 order-lg-2">
                      <img src={home2} alt="Online employee management" class="w-100"/>
                    </div>
                </div>
                <h3 >What are the Benefits of an Employee Management System?</h3>
                <p>Benefits of an EMS are as follows-</p>

            <ul >
	            <li>HR data analytics</li>
	            <li >Secured data</li>
	            <li>Keeps track of leave and attendance</li>
	            <li>Reduces paperwork</li>
	            <li >Saves HR time</li>
	            <li >Zeroed errors</li>
            </ul>
            </div><br/>
            <Footer/>
        </div>
    )
}
export default Manageemp;