import React, { useEffect, useState } from 'react';
import Adminheader from './Adminheader';
import axios from 'axios';
import {useForm} from "react-hook-form";

function EditEmployee(){
  const [errorList, setErrorList] = useState([]);
    const[pwd,setPwd]=useState();
    const[fname,setFname]=useState();
    const[lname,setLname]=useState();
    const[email,setEmail]=useState();
    const[city,setCity]=useState();
    const[address,setAddress]=useState();
    const[state,setState]=useState();
    const[pin,setPin]=useState();
    const[designation,setDesignation]=useState();
    const[phone,setPhone]=useState();
    const[error,setError]=useState("");
    const[user,setUser]=useState([]);

    useEffect(() => {
        axios.get("http://localhost:8080/getEmployee/" + localStorage.getItem("userId")).then((response) => {
        setPwd(response.data.password);
        setFname(response.data.fname);
        setLname(response.data.lname);
        setEmail(response.data.email);
        setAddress(response.data.address);
        setCity(response.data.city);
        setState(response.data.state);
        setPin(response.data.pincode);
        setDesignation(response.data.designation);
        setPhone(response.data.phone);  
        });
      }, []);

        function editUser(){
          if(pwd==""||fname==""||lname==""||email==""||address==""||city==""||state==""||pin==null||designation==""||phone==""){
            setErrorList(["*All input fields are required. Please enter all fields*"]);
            console.log(errorList);
            }
            else{
              if(!(pwd===""||fname===""||lname===""||email===""||address===""||city===""||state===""||pin===null||designation===""||phone==="")){
                setErrorList([null]);
                console.log(errorList);
        axios.put("http://localhost:8080/updateEmployee/"+localStorage.getItem("userId"),{
            
            password: pwd,
            fname: fname,
            lname:lname,
            email: email,
            address: address,
            city: city,
            state: state,
            pincode:pin,
            designation: designation,
            phone:phone
            
          })
          .then((response) => {
            setUser(response.data)
             alert('Employee updated Successfully')
         })
         .catch((error) => {
          setError(error.response.data)
          console.log(error.response.data)
        })
      }
      }
      }

      const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        trigger,
      } = useForm();
    
      const onSubmit = (data) => {
        console.log(data);
        reset();
      };
      
     
    return(
        <div>
            <Adminheader/>
            <div class="container"><br/>
                <h2>Edit Employee Details</h2><br/>
                <div class="col-lg-12 well">
                <div class="row">
                    <form action="adminHome" onSubmit={handleSubmit(onSubmit)}>
                    
          {errorList.map((msg) => (
            <p style={{ color: "red" }}>{msg}</p>
          ))}
        
                        <div class="col-sm-12" >
                            <div class="row">
                          
                                <div class="col-sm-6 form-group">
                                     <label>Password:</label>
                                     <input type="password" 
                                     name="pwd" 
                                     id="password"  
                                     placeholder="Enter Password Here.."  
                                     className={`form-control ${errors.password && "invalid"}`}
                                     {...register("password", { required: "Password is Required" })}
                                     onKeyUp={() => {
                                     trigger("password");
                                     }}
                                     onInput={(event)=> setPwd(event.target.value)} required 
                                     value={pwd}/>
                                     {errors.password && (
                                     <small className="text-danger">{errors.password.message}</small>
                                    )}
                                    
                                     </div>
                                </div>
                                <br/>
                                <div class="row">
                                 <div class="col-sm-6 form-group">
                                     <label>First Name</label>
                                     <input type="text" 
                                     name="fname" 
                                     id="fname" 
                                     placeholder="Enter First Name Here.." 
                                     className={`form-control ${errors.fname && "invalid"}`}
                                     {...register("fname", { required: "First Name is Required" })}
                                     onKeyUp={() => {
                                       trigger("fname");
                                     }}
                                     onInput={(event)=> setFname(event.target.value)} required 
                                     value={fname}/>
                                     {errors.fname && (
                                     <small className="text-danger">{errors.fname.message}</small>
                                    )}
                                    
                                </div>
                                 <div class="col-sm-6 form-group">
                                     <label>Last Name</label>
                                    <input type="text" 
                                    name="lname" 
                                    placeholder="Enter Last Name Here.." 
                                    className={`form-control ${errors.lname && "invalid"}`}
                                     {...register("lname", { required: "Last Name is Required" })}
                                     onKeyUp={() => {
                                       trigger("lname");
                                     }}
                                    onInput={(event)=> setLname(event.target.value)} required 
                                    value={lname}/>
                                     {errors.lname && (
                                     <small className="text-danger">{errors.lname.message}</small>
                                    )}
                                    
                                </div>
                            </div>		
                            <div class="form-group">
                                 <label>Email Address</label>
                                 <input type="text" 
                                 name="email" 
                                 placeholder="Enter Email Address Here.." 
                                 className={`form-control ${errors.email && "invalid"}`}
                                 {...register("email", { required: "Email is Required" ,
                                 pattern: {
                                 value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                 message: "Invalid email address, give valid email",
                                 }})}
                                 onKeyUp={() => {
                                 trigger("email");
                                 }}
                                 onInput={(event)=> setEmail(event.target.value)} required 
                                 value={email}/>
                                 {errors.email && (
                                 <small className="text-danger">{errors.email.message}</small>
                                 )}
                            </div>				
                            <div class="form-group">
                                 <label>Address</label>
                                 <textarea placeholder="Enter Address Here.." 
                                 rows="3"  
                                 name="address" 
                                 className={`form-control ${errors.address && "invalid"}`}
                                 {...register("address", { required: "Address is Required",
                                })}
                                 onKeyUp={() => {
                                 trigger("address");
                                 }}
                                 onInput={(event)=> setAddress(event.target.value)} required 
                                 value={address}></textarea>
                                 {errors.address && (
                                 <small className="text-danger">{errors.address.message}</small>
                                 )}
                            </div>	
                             <div class="row">
                                 <div class="col-sm-4 form-group">
                                    <label>City</label>
                                     <input type="text" 
                                     name="city" 
                                     placeholder="Enter City Name Here.."
                                     className={`form-control ${errors.city && "invalid"}`}
                                     {...register("city", { required: "City is Required",
                                    })}
                                     onKeyUp={() => {
                                     trigger("city");
                                     }} 
                                     onInput={(event)=> setCity(event.target.value)} required 
                                     value={city}/>
                                      {errors.city && (
                                    <small className="text-danger">{errors.city.message}</small>
                                     )}   
                                </div>	
                                <div class="col-sm-4 form-group">
                                   <label>State</label>
                                    <input type="text" 
                                    name="state" 
                                    placeholder="Enter State Name Here.." 
                                    className={`form-control ${errors.state && "invalid"}`}
                                     {...register("state", { required: "State is Required",
                                    })}
                                     onKeyUp={() => {
                                     trigger("state");
                                     }} 
                                     onInput={(event)=> setState(event.target.value)} required 
                                     value={state}/>
                                     {errors.state && (
                                      <small className="text-danger">{errors.state.message}</small>
                                     )}
                                 </div>	
                                <div class="col-sm-4 form-group">
                                  <label>Pin code</label>
                                    <input type="text" 
                                    name="pin" 
                                    placeholder="Enter pin Code Here.." 
                                    title="Give 6 digit pincode " 
                                    className={`form-control ${errors.pincode && "invalid"}`}
                                    {...register("pincode", { required: "pincode is Required",
                                     pattern: {
                                     value: /[1-9]{1}[0-9]{5}/,
                                       message: "invalid pincode, enter 6 digit number",
                                       }
                                        })}
                                      onKeyUp={() => {
                                     trigger("pincode");
                                     }}
                                     onInput={(event)=> setPin(event.target.value)} required 
                                     value={pin}/>
         
                                </div>	
                                     {errors.pincode && (
                                     <small className="text-danger">{errors.pincode.message}</small>
                                     )}	
                         </div>  
                        <div class="form-group">
                             <label>Designation</label>
                             <input type="text" 
                             name="designation" 
                             placeholder="Enter Designation Here.."  
                             className={`form-control ${errors.designation && "invalid"}`}
                             {...register("designation", { required:"Designation is Required",
                              maxLength: {
                              value: 40,
                                message: "Maximum allowed length is 40 ",
                                }
                                 })}
                               onKeyUp={() => {
                              trigger("designation");
                              }}
                              onInput={(event)=> setDesignation(event.target.value)} required 
                              value={designation}/>
                               {errors.designation && (
                               <small className="text-danger">{errors.designation.message}</small>
                                )}
                      
                        </div>						
                        <div class="form-group">
                         <label>Phone Number</label>
                         <input type="tel" 
                         id="phone" 
                         name="phone" 
                         placeholder="Enter Phone Number Here.." 
                         className={`form-control ${errors.phone && "invalid"}`}
                         {...register("phone", { required: "Phone is Required",
                         pattern: {
                         value: /[6-9]{1}[0-9]{9}/,
                         message: "Invalid Phone Number, Mobile number consists of 10 digits, starts with 6/7/8/9",
                         },
                         })}
                         onKeyUp={() => {
                         trigger("phone");
                         }}
                         onInput={(event)=> setPhone(event.target.value)} required 
                         value={phone}/>
                        </div>		
                        {errors.phone && (
                         <small className="text-danger">{errors.phone.message}</small>
                          )}
                        <br/> <input type="button" class="btn btn-primary" value="Submit" onClick={()=>editUser()} /> 			
                         
                     </div>
              </form> 
            </div>
        </div>
    </div>
   </div>
    )
}

export default EditEmployee;   