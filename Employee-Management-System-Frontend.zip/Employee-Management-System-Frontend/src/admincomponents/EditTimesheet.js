import React, { useState } from 'react';
import Adminheader from './Adminheader';
import axios from 'axios';

function EditTimesheet(){
  
  const[user,setUser]=useState([]);
 
  const[status,setStatus]=useState();

  
  function editTimesheet(){
    
    axios.put("http://localhost:8080/updateTimesheet/"+localStorage.getItem("tid")+"/"+localStorage.getItem("wdescription")
          +"/"+localStorage.getItem("hour")+"/"+localStorage.getItem("tidate"),{
        
         timesheet_status: status
      })
    .then((response) => {
        setUser(response.data)
        alert('Timesheet updated successfully');
    })
    .catch((error) => {
    
      console.log(error)
    })
  }

    return(
        <div>
            <Adminheader/>
            <div class="container"><br/>
            <h2>Edit Timesheet</h2><br/>
            <div className = "card col-md-6 offset-md-3"><br/>
            <div class="container">
                  <form action="adminHome" >
                    <div class="col-sm-12">
                    <div class="form-group">
                      <label>Status</label>
                      <select class="form-select" onInput={(event)=> setStatus(event.target.value)}>
                        <option selected>Select Status</option>
                        <option>Approved</option>
                        <option>Rejected</option>
                      </select>
                    </div><br/>
                    <input type="button" class="btn btn-primary" value="Submit" onClick={()=>editTimesheet()} /> 	
                  
                </div>
            </form>
        </div>
    </div>
</div>
        </div>
    )
}

export default EditTimesheet;