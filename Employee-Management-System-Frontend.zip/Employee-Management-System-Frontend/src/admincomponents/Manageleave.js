import React from 'react';
import img1 from '../assets/leavemng.jpg';
import logo from '../assets/home1.jpg';
import img2 from '../assets/leavemng2.webp';
import img3 from '../assets/Win-flexibility-with-Online-leave-management-software.webp';
import img4 from '../assets/Improve-workforce-productivity.webp';
import img5 from '../assets/leave.png';
import Footer from '../menucomponents/Footer';

function Manageleave()
{
    return(
        <div>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="adminHome">
                         <img src={logo}  style={{height:"70px",width:"90px"}} alt=""/>
                     </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                         <span class="navbar-toggler-icon"></span>
                    </button> 
                     <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                 <a href="addleave">Add Leave</a>
                            </li>
                            <li class="nav-item">
                                <a href="leaveReport"> Leave Report</a>
                            </li>
                
                        </ul>
                    </div>
                </div>
            </nav> 
             <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src={img1} class="d-block w-100" alt="EmpHome" style={{height:"450px",width:"500px"}} />
                  </div>
                  <div class="carousel-item">
                    <img src="http://www.wolke.ae/wp-content/uploads/2017/07/banner_leave_management-1.jpg" class="d-block w-100" alt="EmpHome" style={{height:"450px",width:"500px"}} />
                  </div>
                </div>
                  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                  </button>
                  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                  </button>
            </div><br/>
            <section class="one-platform go-paperless">
              <div class="container">
                    <div class="headings text-center">
                      <h2 ><span>Automate and streamline your leave management process</span></h2>
                    </div><br/>
                  <div class="row justify-content-between">
                    <div class="card text-white bg-warning mb-3" style={{maxWidth: "18em"}}>
                      <div class="card-body">
                        <h5 class="card-title">Automated leave management</h5>
                        <p class="card-text">Get your processes streamlined with Pocket HRMS. </p>
                      </div>
                    </div>
                    <div class="card text-dark bg-success mb-3" style={{maxWidth: "18em"}}>
                      <div class="card-body">
                          <h5 class="card-title">Error-free and timely payroll</h5>
                          <p class="card-text">Foolproof attendance data leads to accurate and on-time payroll.</p>
                      </div>
                    </div>
                    <div class="card text-white bg-danger mb-3" style={{maxWidth: "18em"}}>
                      <div class="card-body">
                        <h5 class="card-title">Save more time</h5>
                        <p class="card-text">All-in-one HRMS solution ensures smooth operation of employee leave management</p>
                      </div>
                    </div>
                  </div>
                </div>
            </section><br/><br/>
            <section class="best-payroll-software">
              <div class="container">
                <div class="row align-items-center justify-content-between">
                  <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center">
                    <img src={img2} alt="employee leave management" class="w-100"/>
                  </div>
                  <div class="col-lg-6">
                    <div class="headings mb-4">
                        <h3><span class="d-block">Streamline employee leave management without a hassle</span></h3>
                    </div>
                    <p>You can manage and track employee leaves with our dedicated leave management system. The simple and easy-to-use interface of our software makes leave processing easy for both the employees and employers. An <strong>employee leave management system</strong> will let you no more worry about data integration or miscalculations.</p>
                  </div>
                </div>
                </div>
            </section><br/>
            <div class="feature-details">
              <div class="container">
                <div class="row align-items-center py-5 feature-service-details">
                  <div class="col-lg-6 order-2 order-lg-1">
                    <div class="headings mb-3">
                      <h3><span>Win flexibility with Online leave management software</span></h3>
                    </div>
                    <p>The software lets you and your employees approve and apply for leaves respectively with ease through its dedicated leave management module. This gives flexibility to your work culture bringing in better work environment.</p>
                  </div>
                  <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center order-1 order-lg-2">
                    <img src={img3} alt="Online leave management software" class="w-100"/>
                  </div>
                </div>
                <div class="row align-items-center py-5 feature-service-details">
                  <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center">
                    <img src={img4} alt="Improve workforce productivity" class="w-100"/>
                  </div>
                  <div class="col-lg-6">
                    <div class="headings mb-3">
                      <h3><span>Improve workforce productivity</span></h3>
                    </div>
      
                    <p>Be prompt while attending leave requests. HRs now do not need to run through tons of procedures for even small approvals. Leave management system lets you manage leave related concerns with comfort. As a result, employees need not wait for decades for their requests getting attended by their HR or manager. Hence, all these adds up to improving workforce efficiency and productivity. Our system help employees for checking leave balance, approved leaves and other details.</p>
                  </div>
                </div>
                <div class="row align-items-center py-5 feature-service-details">
                  <div class="col-lg-6 order-2 order-lg-1">
                    <h2>What is Leave Management System?</h2>
      
                       <p>It is a dashboard that allows an employer to accurately allocate, track, manage and grant/reject leave and also employees can request and track their own leaves. By accessing this system, the human resource department can easily manage, track and store employees leave requests in an efficient and accurate manner.</p>
                  </div>
                  <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center order-1 order-lg-2">
                    <img src={img5} alt="" class="w-100"/>
                  </div>
                </div>
              
              <h3 >What are the Benefits of using Leave Management System?</h3>

              <ul >
	                <li >Tracking employee leaves</li>
                	<li >Accurate attendance details</li>
                	<li >No more spreadsheets</li>
	                <li>Human errors at bay</li>
	                <li >Real-time visibility</li>
                	<li >Improves communication</li>
                	<li >Easy data access</li>
              </ul>
            </div>
          </div><br/>
          <Footer/>
        </div>
    )
}

export default Manageleave;