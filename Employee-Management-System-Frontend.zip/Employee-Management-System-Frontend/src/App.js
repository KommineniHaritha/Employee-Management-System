import React from 'react';
import {BrowserRouter,Route,Switch}from "react-router-dom";
import './App.css';

import Home from './menucomponents/Home';
import Adminlogin from './admincomponents/Adminlogin';
import EditEmployee from './admincomponents/EditEmployee';
import Aboutus from './menucomponents/Aboutus';
import Adminhome from './admincomponents/Adminhome';
import AddEmployee from './admincomponents/AddEmployee';
import AddLeave from './admincomponents/AddLeave';
import AddSalary from './admincomponents/AddSalary';
import AddTimesheet from './admincomponents/AddTimesheet';
import LeaveReport from './admincomponents/LeaveReport';
import SalaryReport from './admincomponents/SalaryReport';
import TimesheetReport from './admincomponents/TimesheetReport';
import ViewAllEmployees from './admincomponents/ViewAllEmployees';
import Manageleave from './admincomponents/Manageleave';
import Managesalary from './admincomponents/Managesalary';
import Managetime from './admincomponents/Managetime';
import Manageemp from './admincomponents/Manageemp'
import Emplogin from './employeecomponents/Emplogin';
import EmpHome from './employeecomponents/EmpHome';
import SubmitTimesheet from './employeecomponents/SubmitTimesheet';
import ApplyLeave from './employeecomponents/ApplyLeave';
import ViewProfile from './employeecomponents/ViewProfile';
import ViewSalary from './employeecomponents/ViewSalary';
import ViewTimesheet from './employeecomponents/ViewTimesheet';
import ViewLeave from './employeecomponents/ViewLeave';
import ForgetPassword from './employeecomponents/ForgetPassword';
import EditLeave from './admincomponents/EditLeave';
import EditTimesheet from './admincomponents/EditTimesheet';
import EditUser from './employeecomponents/EditUser';
import Logout from './menucomponents/Logout';
import AdminLogout from './admincomponents/AdminLogout';

function App() {
  return (
   
    <BrowserRouter>  
    < Switch>

    <Route path="/" exact>  <Home/>  </Route>
    <Route path="/home" exact>  <Home/>  </Route>
    <Route path="/adminLogin" exact>  <Adminlogin/>  </Route> 
    <Route path="/about" exact>  <Aboutus/>  </Route>
    <Route path="/adminHome" exact>  <Adminhome/>  </Route>
    <Route path="/addleave" exact>  <AddLeave/>  </Route>
    <Route path="/addsalary" exact>  <AddSalary/>  </Route>
    <Route path="/addtime" exact>  <AddTimesheet/>  </Route>
    <Route path="/addemp" exact>  <AddEmployee/>  </Route>
    <Route path="/viewAllEmployees" exact>  <ViewAllEmployees/>  </Route>
    <Route path="/leaveReport" exact>  <LeaveReport/>  </Route>
    <Route path="/salaryReport" exact>  <SalaryReport/>  </Route>
    <Route path="/timeReport" exact>  <TimesheetReport/>  </Route>
    <Route path="/manageemp" exact>  <Manageemp/>  </Route>
    <Route path="/manageleave" exact>  <Manageleave/>  </Route>
    <Route path="/managesalary" exact>  <Managesalary/>  </Route>
    <Route path="/managetimesheet" exact>  <Managetime/>  </Route>
    <Route path="/empLogin" exact>  <Emplogin/>  </Route>
    <Route path="/empHome" exact>  <EmpHome/>  </Route>
    <Route path="/applyLeave" exact>  <ApplyLeave/>  </Route>
    <Route path="/submitTimesheet" exact>   <SubmitTimesheet/>  </Route>
    <Route path="/viewProfile" exact>  <ViewProfile/>  </Route>
    <Route path="/viewLeave" exact>  <ViewLeave/>  </Route>
    <Route path="/viewSalary" exact>  <ViewSalary/>  </Route>
    <Route path="/viewTimesheet" exact>  <ViewTimesheet/>  </Route>
    <Route path="/forgetPwd" exact>   <ForgetPassword/>  </Route>
    <Route path="/editemp" exact>   <EditEmployee/>  </Route>
    <Route path="/editleave" exact>   <EditLeave/>  </Route>
    <Route path="/edittimesheet" exact>   <EditTimesheet/>  </Route>
    <Route path="/edituser" exact>   <EditUser/>   </Route>
    <Route path="/logout" exact>  <Logout/>    </Route>
    <Route path="/adminlogout"  exact>  <AdminLogout/>  </Route>
    </Switch>
    </BrowserRouter>



  );
}

export default App;
