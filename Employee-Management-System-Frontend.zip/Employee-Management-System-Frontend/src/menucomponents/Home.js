import React from 'react';
import Header from './Header';
import Slides from './Slides';
import HomeContent from './HomeContent';
import Footer from './Footer';
function Home()
{
    return(

      <div>
        <Header/>
        <Slides/>
        <HomeContent/>
        <Footer/>
      </div>

          
    )
}
export default Home;