import React,{ useState } from 'react'
import axios from 'axios';
import Empheader from '../employeecomponents/Empheader';
import { useHistory } from 'react-router-dom';

function Logout()
{
    let history = useHistory();

    function deleteStorage()
    {
    localStorage.removeItem("id");
    history.push("/home")
    }
   
    return(

      <div>
        <Empheader/><br/>
        <div class="container">
        <h3>Logout</h3><br/>
   
        <button class="btn btn-primary btn-lg" onClick={deleteStorage}>Logout</button>
        </div>
        </div>
        
    )
}

export default Logout;



