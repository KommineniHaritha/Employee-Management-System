import React,{ useState } from 'react'
import './Header.css';

import logo from '../assets/emp.png';


function Header() {

    return (
     
    <div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="home">
            <img src={logo}  style={{height:"70px",width:"90px"}} alt=""/>
          </a>
             <a class="navbar-brand" href="home"><b>COGNIZANT EMS</b></a>
             <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
             </button>
             <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent" >
               <ul class="navbar-nav">
                  <li class="nav-item">
                     <a href="home">Home</a>
                  </li>
                  <li class="nav-item">
                     <a href="empLogin">Employee Login</a>
                  </li>
                  <li class="nav-item">
                      <a href="adminLogin">Admin Login</a>
                  </li>
                  <li class="nav-item">
                     <a href="about">About Us</a>
                  </li>
                
                </ul>
              </div>
          </div>
    </nav> 
    
    </div>
    )
  }


export default Header;
