import React from 'react';
import home2 from '../assets/Save-more-time.webp';

import home3 from '../assets/Ease-your-decision-making.webp';
import home4 from '../assets/On-time,-swift-payroll.jpg';
import home5 from '../assets/Happy-workforce.webp';
import home1 from '../assets/Employee management system.jpg';
import home6 from '../assets/Online-employee-management.webp';
import home7 from '../assets/Self-service-portal.webp';

function HomeContent()
{
    return(

            <div><br/><br/>
             <section class="one-platform go-paperless">
            <div class="container">
              <div class="headings text-center">
                <h2 ><span>Online Employee Management System involves Employee Management, Leave Management, Salary Management and Timesheet Management</span></h2>
              </div><br/>
            <div class="row justify-content-between">
              <div class="card text-white bg-primary mb-3" style={{maxWidth: "18em"}} >
                <div class="card-body">
                  <h5 class="card-title">Rescue more time</h5>
                  <p class="card-text">Save substantial amount of time with our employee management system. </p>
                </div>
              </div>
              <div class="card text-dark bg-warning mb-3" style={{maxWidth: "18em"}}>
                <div class="card-body">
                    <h5 class="card-title">Better decisions</h5>
                    <p class="card-text">The analytically driven metric system provides best insights of business.</p>
                </div>
              </div>
              <div class="card text-white bg-success mb-3" style={{maxWidth: "18em"}}>
                <div class="card-body">
                  <h5 class="card-title">Timely payrolls</h5>
                  <p class="card-text">Automated mechanism of payroll leads to on-time processes.</p>
                </div>
              </div>
              <div class="card text-white bg-danger mb-3" style={{maxWidth: "18em"}}>
                <div class="card-body">
                  <h5 class="card-title">Employee self-service</h5>
                  <p class="card-text">Let your employees service themselves to save more time at HR base.</p>
                </div>
              </div>
            </div>
          </div>
          </section><br/><br/>
      <section class="best-payroll-software">
        <div class="container">
          <div class="row align-items-center justify-content-between">
            <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center">
              <img src={home1} alt="employee management system" class="w-100" />
            </div>
            <div class="col-lg-6">
              <div>
                <h2>What is Employee Management System?</h2>
              </div>
              <p>An Employee Management System is a platform where all work-related as well as important personal details of an employee is stored and managed in a secure way. By using this system, you can manage admin activities in an easier and quicker way.</p>
              <p>Employees are the pillar of any organization and an ideal employee management tool makes a big difference to an organization.</p>
            </div>
          </div>
        </div>
      </section>
        <div class="feature-details">
          <div class="container">
            <div class="row align-items-center py-5 feature-service-details">
              <div class="col-lg-6 order-2 order-lg-1">
                <div class="headings mb-3">
                  <h3>Save more time</h3>
                </div>
                <p>Our HR software solution offers an intelligent module that keeps you organized all the time by providing all data of employees at your fingertips. By using this application, you can access the information related to your staff while you are traveling, through our application. Your HR department now does not need to crawl through multiple files and spreadsheets to get the information of an employee thereby saving a substantial amount of time at their end. You can therefore, invest these saved hours in other developments.</p>
              </div>
              <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center order-1 order-lg-2">
                <img src={home2} alt="Save more time" class="w-100"/>
              </div>
            </div>
            <div class="row align-items-center py-5 feature-service-details">
              <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center">
                <img src={home3} alt="Ease your decision-making" class="w-100"/>
              </div>
              <div class="col-lg-6">
                <div class="headings mb-3">
                  <h3>Ease your decision-making</h3>
                </div>
                <p>By accessing employee management system, you can either customize or create your own metrics or also avail the standard metric system to have an upper-view of entire employee management. Also, you can motivate and support your staff with an analytically driven metric system. With its timesheet management and time tracking software, it becomes easier to decision-making and no more errors are committed thereafter.</p>
              </div>
            </div>
            <div class="row align-items-center py-5 feature-service-details">
              <div class="col-lg-6 order-2 order-lg-1">
                <div class="headings mb-3">
                  <h3>On-time, swift payroll</h3>
                </div>
                <p>Performing payroll was never a piece of cake for the HR team. Moreover, paying them correctly and on time is another major challenge and very important as well. Our employee salary management software helps you with this critical task and makes payroll computation easy. Employee management system helps you pay your employees on time without pushing you into any unwanted legal matters.</p>
              </div>
              <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center order-1 order-lg-2">
                <img src={home4} alt="On-time, swift payroll" class="w-100"/>
              </div>
            </div>
            <div class="row align-items-center py-5 feature-service-details">
              <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center">
                <img src={home5} alt="Happy workforce" class="w-100"/>
              </div>
              <div class="col-lg-6">
                <div class="headings mb-3">
                  <h3>Happy workforce</h3>
                </div>
                <p>It takes productivity of your staff to the next level by appreciating their dedicated hard work for you. Timely payrolls and recognized hard work all adds up to the happy workforce. Data-rich salary slips and downloadable reports tend to improve HR-employee relations thus, improving workforce retention and productivity. Now, you can expect a better business performance.</p>
              </div>
            </div>
            <div class="row align-items-center py-5 feature-service-details">
              <div class="col-lg-6 order-2 order-lg-1">
                <div class="headings mb-3">
                  <h3>Online Employee Management</h3>
                </div>
                <p>Tracing and recording of the employee data had never been easier. Creating a proper employee database is an important to-do task for perfect payroll. Our online employee management software is an essential tool to count exact worked hours and creates the required database for every month. Also, automation helps in cutting down errors. The <strong>online employee management system</strong> lets your HR work from any remote location as well.</p>
              </div>
              <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center order-1 order-lg-2">
                <img src={home6} alt="Online employee management" class="w-100"/>
              </div>
            </div>
            <div class="row align-items-center py-5 feature-service-details">
              <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-between align-items-center">
                <img src={home7} alt="Self-service portal" class="w-100"/>
              </div>
              <div class="col-lg-6">
                <div class="headings mb-3">
                  <h3>Self-service portal</h3>
                  <p>Employee Management System also offers a dedicated platform for employees to access the information regarding their leaves, salary, pay slips, HR data, manager details, etc. This tends to save a lot of your HR efforts and time. As the name suggests, the portal allows your employees to service themselves and get their queries attended immediately.</p>
                </div>
              </div>   			
            </div>
          </div>
        </div>
       </div>
    )
}

export default HomeContent;