import React from 'react';
import './Footer.css';
import twitter from '../assets/Twitter.jpg';
import fb from '../assets/Facebook.jpg';
import insta from '../assets/Instagram.jpg';
import icon from '../assets/emp.png';


function Footer(){
    return(
        <div>
            <footer >
                <div class="social-footer">
                    <div class="center">
                        <img src={twitter} alt="Twitter" style={{height:"48px",width:"55px"}}/>
                    </div>
                </div>
                <div class="social-footer">
                    <div class="center">
                        <img src={fb} alt="FB" style={{height:"55px",width:"28px"}}/>
                    </div>
                </div>
                <div class="social-footer">
                    <div class="center">
                        <img src={insta} alt="Insta" style={{height:"52px",width:"52px"}}/>
                    </div>
                </div>
                <p style={{align:"center", paddingTop:"300px",paddingLeft:"680px"}}><a href="home"><img src={icon} style={{width:"143px" ,height:"80px"}}/></a></p>
                <span class="copyright1">&copy; Copyright 2020 Employee Management System</span>
            </footer>
        </div>
    )
}
export default Footer;
