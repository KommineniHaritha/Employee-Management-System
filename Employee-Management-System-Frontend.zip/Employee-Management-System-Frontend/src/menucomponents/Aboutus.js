import React from 'react';
import Header from './Header';
import Footer from './Footer';

function Aboutus(){
    return(
        <div>
            <Header/>
            <br/>
            <div class="container">
            <h2>ABOUT US</h2><br/>
            <div className="card">
            
                <div class="card-body">
                  <h3 class="card-title"><u>Introduction</u></h3><br/>
                  <p class="card-text">
                      Employee Management System is a function in organizations designed to maximize employee performance of an employer’s strategic objectives. 
                  HR is primarily concerned with management of people within organizations, focusing on policies and systems. 
                  HR departments and units in organization typically undertake number of activities, including employee requirement, training and development, performance appraisal, and rewarding 
                  (e.g., managing pay and benefit systems). HR is also concerned with industrial relations, that is, the balancing of organizational practices with requirements arising from governmental laws. 
                  </p>
                  <p class="card-text">
                  HR is a product of the human relations movement of early 20th century, when researches began documenting ways of creating business values through the strategic management of the workforce. 
                  The function was initially dominated by transactional work, such as payroll and benefits administration, but due to globalization, company consolidation, technological advances, and further research, 
                  HR as of 2015 focuses on strategic initiatives like mergers and acquisitions, talent management, planning, industrial and labor relations, and diversity and inclusion.
                  </p>
                  <p class="card-text">
                  In startup companies, HR duties may be performed by trained professionals. In larger companies, an entire functional group is typically dedicated to discipline, with staff specializing in various
                   HR tasks and functional leadership engaging in strategic decision making across the business. To train practitioners for the profession, institutions of higher education, professional associations and 
                   companies themselves have created programs of study dedicated explicitly to the duties of the function.
                  </p>
                  <p class="card-text">
                  In the current global work environment, most companies focus on employee turnover and the knowledge held by their workforce. 
                  New hiring nor only emails a high cost but also increases the risk of a newcomer not being able to replace the person who was working in that position before. 
                  HR departments strive to offer benefits that will appeal to workers, then reducing the risk of losing corporate knowledge.
                  </p>
                    <br/>
                  <h3 class="card-title"><u>Contact us</u></h3><br/>
                  <h5 class="card-text">
                    Contact us for any queries either through Email or Mobile.
                  </h5>
                  <p class="card-text">
                      Email : emshr@gmail.com
                  </p>
                  <h6 class="card-text">
                      Mobile Numbers:
                  </h6>
                  <p class="card-text">
                      Haritha Kommineni : 9121376526
                  </p>
                  <p class="card-text">
                      Aravind A : 9080627892
                  </p>
                  <p class="card-text">
                      Aravindh M : 7904114399
                  </p>
                  <p class="card-text">
                      Yeswanth Reddy : 9440059738
                  </p><br/>

                </div>
            </div><br/>
            </div>
            <Footer/>
        </div>
      
    )
}

export default Aboutus;