import React,{ useEffect,useState } from 'react'
import axios from 'axios';
import Empheader from './Empheader';
import './card.css';
import { useHistory } from 'react-router-dom';

function ViewProfile(){

    const[user,setUser]=useState([]);
    const[error,setError]=useState("");
    let history = useHistory();
    const id=localStorage.getItem("id");

    useEffect(()=>{
        axios.get("http://localhost:8080/getEmployee/"+id)
        .then((response) => {
            setUser(response.data)
            
        })
        .catch((error) => {
          setError(error.response.data)
          console.log(error.response.data)
        })
    })

    function editEmployee(id)
    {
     // localStorage.setItem("empId",id)
         history.push("/edituser")
    }

    return(
        <div >
            <Empheader/>
            <div class="container"><br/>
                <h2>View Details</h2><br/>
            <div className = "card col-md-5 offset-md-4">
            <div class="card-header text-white bg-primary">Profile</div>
                <div className = "card-body">
                    <div class= "row">   
                         Employee Id :  {user.id}
                    </div>
                    <div className = "row">
                         First Name :  {user.fname}
                    </div>
                    <div className = "row">
                         Last Name : {user.lname}
                    </div>
                    <div className = "row">
                         Email Id : {user.email}
                    </div>
                    <div className = "row">
                        Address :  {user.address}
                    </div>
                    <div className = "row">
                        City :  {user.city}
                    </div>
                    <div className = "row">
                        State :  {user.state}
                    </div>
                    <div className = "row">
                         Pincode: {user.pincode}
                    </div>
                    <div className = "row">
                        Designation: {user.designation}
                    </div>
                    <div className = "row">
                         Mobile number: {user.phone}
                    </div>
                </div>
                <div class="card-footer">
                <button class="btn btn-success btn-lg" onClick={()=>editEmployee(user.id)}>Edit</button>
                
                </div>
            </div>
            </div>
        </div>
    )
}
export default ViewProfile;