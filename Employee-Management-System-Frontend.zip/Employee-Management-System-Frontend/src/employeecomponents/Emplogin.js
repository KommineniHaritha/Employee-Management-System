import React,{ useState } from 'react'
import axios from 'axios';
import Header from '../menucomponents/Header';
import '../admincomponents/Adminlogin.css';
import { useHistory } from 'react-router-dom';

function Emplogin()
{
  const [login, setLogin] = useState({ });
  const [errorList, setErrorList] = useState([]);
  const[users,setUsers]=useState();
  let history = useHistory();

   const getvalues = (event) => {
    setLogin({ ...login, [event.target.name]: event.target.value });
    console.log(login);
  };

  function validate() {
    if (login.id == null || login.password === "") {
      setErrorList(["Id is required", "Password is required"]);
      console.log(errorList);
    } else {
      axios
        .post("http://localhost:8080/login/", login)
        .then((response) => {
          localStorage.setItem("id",login.id)
          history.push('/EmpHome')
        alert("Successfully loggedin")
    
        })
        .catch((error) => {
         setErrorList(["Invalid id/password"]);
        
        });
    }
  }
  return(
        
      <div>
      <Header/>
      <div class="container login-container">
          <div class="col-md-6 login-form-2">
            
            <h3>Employee login</h3><br/>
                   
        <ul>
        {errorList.map((msg) => (
          <li style={{ color: "white" }}>{msg}</li>
        ))}
      </ul>
    
      <input type="text" className="form-control" name="id" placeholder="enter id" onChange={getvalues} required ></input>
      <br/>
     
      <input type="password" className="form-control" name="password" placeholder="enter password" onChange={getvalues} required></input>
      <br></br>

      <div class="form-group">
          <input type="submit" class="btnSubmit" value="Login" onClick={()=>validate()} />
      </div><br/>
    
      <div class="form-group">
          <a href="forgetPwd" class="ForgetPwd" value="Login">Forgot Password?</a>
      </div>

          </div>
      </div>
      </div>
 
    )
}
export default Emplogin;