import React,{ useEffect,useState } from 'react'
import axios from 'axios';
import Empheader from './Empheader';

function ViewTimesheet(){

    const[users,setUsers]=useState([]);
    const[error,setError]=useState("");

    const id=localStorage.getItem("id");

    useEffect(()=>{
        axios.get("http://localhost:8080/getTimesheet/"+id)
        .then((response) => {
            setUsers(response.data)
            
        })
        .catch((error) => {
          setError(error.response.data)
          console.log(error.response.data)
        })
    })

    return(
        <div>
            <Empheader/>
            <div class="container"><br/>
                <h2>View Timesheet</h2><br/>
                
                <table class="table table-bordered">
                 
                 <tr><th>Work Description</th><th>Working hours</th><th>Date</th><th>Status</th></tr>
                 
                 <tbody>
                     {users.map((user)=><tr><td>{user.work_description}</td><td>{user.hours}</td><td>{user.tdate}</td><td>{user.timesheet_status}</td></tr>)}
                 </tbody>
         </table><br/>

            </div>
        </div>
    )
}
export default ViewTimesheet;