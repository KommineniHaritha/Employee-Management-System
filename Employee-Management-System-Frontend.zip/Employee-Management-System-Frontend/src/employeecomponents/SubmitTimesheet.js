import React, { useState } from 'react';
import axios from 'axios';
import Empheader from './Empheader';
import {useForm} from "react-hook-form";
import $ from 'jquery';
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

function SubmitTimesheet(){

  const [errorList, setErrorList] = useState([]);

  const[description,setDescription]=useState();
  const[date,setDate]=useState();
  const[status,setStatus]=useState();
  const[hours,setHours]=useState();
  const[error1,setError1]=useState("");

  const id=localStorage.getItem("id");

  function submitTimesheet(){
    if(description== null|| hours== null|| date==="" || status== null){
      setErrorList(["*All input fields are required. Please enter all fields*"]);
      console.log(errorList);
    }else{
    axios.post("http://localhost:8080/submitTimesheet/"+id,{
        
        work_description: description,
        hours:hours,
        tdate: date,
        timesheet_status: status
      })
    .then((response) => {
      
        alert('Timesheet submitted successfully');
    })
    .catch((error1) => {
      setError1(error1.response.data)
      console.log(error1.response.data)
    })
  }
  }

  $(function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var minDate = year + '-' + month + '-' + day;

    // or instead:
    // var maxDate = dtToday.toISOString().substr(0, 10);

    
    $('#todayDate').attr('min', minDate);
    $('#todayDate').attr('max', minDate);
    
});


    return(
        <div>
            <Empheader/>
            <div class="container"><br/>
            <h2>Submit Timesheet</h2><br/>
            <div className = "card col-md-6 offset-md-3"><br/>
            <div class="container">
                  <form class="row g-3 needs-validation">
                
          {errorList.map((msg) => (
            <li style={{ color: "red" }}>{msg}</li>
          ))}
        
                    <div class="col-sm-12">
                   
                    <div class="form-group">
                        <label>Work Description</label>
                        <textarea placeholder="Enter Work Description Here.." rows="2" class="form-control" onInput={(event)=> setDescription(event.target.value)} required></textarea>
                    </div><br/>

                    <div class="form-group">
                        <label>Working hours</label>
                        <input type="number" min="2" max="10" placeholder="Total working hours." class="form-control" onInput={(event)=> setHours(event.target.value)} required/>
                    </div><br/>
                    <div class="form-group">
                      <label>Date</label>
                      <input type="date" id="todayDate" placeholder="Select Date" class="form-control" max onInput={(event)=> setDate(event.target.value)}  required/>
                    </div>	<br/>

                    <div class="form-group">
                      <label>Status</label>
                      <select class="form-select" onInput={(event)=> setStatus(event.target.value)}>
                        <option selected>Select Status</option>
                        <option>Submitted for Approval</option>     
                      </select>
                    </div>
                    </div>
                      <input type="button" class="btn btn-primary" value="Submit" onClick={()=>submitTimesheet()} /> 	
                    {error1}
               
            </form>
        </div>
    </div>
</div>
        </div>
    )
}

export default SubmitTimesheet;