
import React,{ useEffect,useState } from 'react'
import axios from 'axios';
import Empheader from './Empheader';

function ViewSalary(){

    const[users,setUsers]=useState([]);
    const[error,setError]=useState("");

    const id=localStorage.getItem("id");

    useEffect(()=>{
        axios.get("http://localhost:8080/getSalary/"+id)
        .then((response) => {
            setUsers(response.data)
            
        })
        .catch((error) => {
          setError(error.response.data)
          console.log(error.response.data)
        })
    })

    return(
        <div>
            <Empheader/>
            <div class="container"><br/>
                <h2>View Salary</h2><br/>
                
                <table class="table table-bordered">
                 
                 <tr><th>Month</th><th>Year</th><th>Amount</th></tr>
                 
                 <tbody>
                     {users.map((user)=><tr><td>{user.sal_month}</td><td>{user.sal_year}</td><td>{user.amount}</td></tr>)}
                 </tbody>
         </table><br/>

            </div>
        </div>
    )
}
export default ViewSalary;