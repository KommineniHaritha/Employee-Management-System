import React,{ useState } from 'react'
import axios from 'axios';
import Header from '../menucomponents/Header';

function ForgetPassword()
{
    const[userId,setUserId]=useState();
    const[pwd,setPwd]=useState();
    const[user,setUser]=useState([])
    const[error1,setError1]=useState("");

    function update(){
        axios.get("http://localhost:8080/forgetPassword/"+userId+"/"+pwd)
        .then((response) => {
            setUser(response.data)
            alert(' Reset Password is successfull');
        })
        .catch((error1) => {
          alert('Employee id does not exist')
          console.log(error1.response.data)
        })
      }

    return(
        <div>
        <Header/>
        <div class="container login-container">
          <div class="col-md-6 login-form-2">
            <h3>Reset Password</h3><br/>
    
            <input type="text" className="form-control" name="id" placeholder="enter id" onInput={(event)=> setUserId(event.target.value)} required ></input>
             <br/>
     
            <input type="password" className="form-control" name="password" placeholder="enter new password" onInput={(event)=> setPwd(event.target.value)} required></input>
             <br></br>

            <div class="form-group">
                 <input type="submit" class="btnSubmit" value="Submit" onClick={()=>update()} />
            </div><br/>

            <div class="form-group">
                 <a href="empLogin" class="ForgetPwd" value="Login">Login?</a>
            </div>

          </div>
        </div>
        </div>
    )
}

export default ForgetPassword;