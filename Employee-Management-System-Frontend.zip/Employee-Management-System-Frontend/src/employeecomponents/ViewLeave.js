import React,{ useEffect,useState } from 'react'
import axios from 'axios';
import Empheader from './Empheader';

function ViewLeave(){

    const[users,setUsers]=useState([]);
    const[error,setError]=useState("");

    const id=localStorage.getItem("id");

    useEffect(()=>{
        axios.get("http://localhost:8080/getLeave/"+id)
        .then((response) => {
            setUsers(response.data)
            
        })
        .catch((error) => {
          setError(error.response.data)
          console.log(error.response.data)
        })
    })


    return(
        <div>
            <Empheader/>
            <div class="container"><br/>
                <h2>View Leave</h2><br/>
                <div class="table-responsive">
  
                <table class="table table-bordered">
               
                 <tr><th>Description</th><th>From_Date</th><th>To_Date</th><th>Status</th></tr>
                
                 <tbody>
                     {users.map((user)=><tr><td>{user.leave_description}</td><td>{user.from_date}</td><td>{user.to_date}</td><td>{user.leave_status}</td></tr>)}
                 </tbody>
         </table><br/>
            </div>
            </div>
        </div>
    )
}

export default ViewLeave;