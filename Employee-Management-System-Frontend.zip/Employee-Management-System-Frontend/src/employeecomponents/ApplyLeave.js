import React, { useState } from 'react';

import axios from 'axios';
import Empheader from './Empheader';
import $ from 'jquery';
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

function ApplyLeave(){

  const [errorList, setErrorList] = useState([]);

  const[leave,setLeave]=useState();
  const[user,setUser]=useState([]);
  const[fdate,setFdate]=useState();
  const[tdate,setTdate]=useState();
  const[status,setStatus]=useState();
  const[error1,setError1]=useState("");

  const id=localStorage.getItem("id");

  function addEmpLeave(){
    if( leave== null|| fdate===""|| tdate==="" || status== null){
      setErrorList(["*All input fields are required. Please enter all fields*"]);
      console.log(errorList);
    }else{
    axios.post("http://localhost:8080/applyLeave/"+id,{
        leave_description: leave,
        from_date:fdate,
        to_date: tdate,
        leave_status: status

      })
    .then((response) => {
        setUser(response.data)
        alert('Applied successfully');
    })
    .catch((error1) => {
      setError1(error1.response.data)
      console.log(error1.response.data)
    })
  }
  }

  $(function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var minDate = year + '-' + month + '-' + day;
  
    // or instead:
    // var maxDate = dtToday.toISOString().substr(0, 10);
  
    $('#fromDate').attr('min', minDate);
    $('#toDate').attr('min', minDate);
  });

    return(
        <div>
            <Empheader/>

            <div class="container"><br/>
          <h2>Apply for Leave</h2><br/>
          <div className = "card col-md-6 offset-md-3"><br/>
            <div class="container">
                <form action="adminHome" class="row g-3 needs-validation">
  
          {errorList.map((msg) => (
            <li style={{ color: "red" }}>{msg}</li>
          ))}
     
                  <div class="col-sm-12">
                                 
                    <div class="form-group">
                      <label>Leave Description</label>
                      <textarea placeholder="Enter Leave Description Here.." rows="2" class="form-control" onInput={(event)=> setLeave(event.target.value)}required></textarea>
                      
                    </div><br/>
                      <div class="form-group">
                      <label>From Date</label>
                      <input type="date" placeholder="Select From Date" class="form-control"  id="fromDate" onInput={(event)=> setFdate(event.target.value)} required/>
                      
                    </div>	<br/>
                    <div class="form-group">
                      <label>To Date</label>
                      <input type="date" placeholder="Select To Date" class="form-control" id="toDate" onInput={(event)=> setTdate(event.target.value)}  required/>
                  
                    </div>	<br/>
                    <div class="form-group">
                      <label>Leave Status</label>
                      <select class="form-select" onInput={(event)=> setStatus(event.target.value)} aria-label="Default select example">
                        <option selected>Select Status</option>
                        <option>Request for leave</option>
                       
                      </select>
                    </div>
                    </div>
                    <input type="button" class="btn btn-primary" value="Submit" onClick={()=>addEmpLeave()} /> 		
                    {error1}	<br/>
             
                </form> 
              </div>
            </div>
        </div>
        </div>
    )
}

export default ApplyLeave;